var import_team_config = require("../../team-config.js");
exports.handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  try {
    const { query } = JSON.parse(event.body || "{}");
    if (!query) {
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          team: Object.values(import_team_config.TEAM_MEMBERS).map((member) => ({
            name: member.name,
            role: member.role,
            department: member.department,
            email: member.id + "@balizero.com"
          })),
          departments: import_team_config.DEPARTMENTS,
          total: Object.keys(import_team_config.TEAM_MEMBERS).length
        })
      };
    }
    const results = Object.values(import_team_config.TEAM_MEMBERS).filter(
      (member) => member.name.toLowerCase().includes(query.toLowerCase()) || member.role.toLowerCase().includes(query.toLowerCase()) || member.department.toLowerCase().includes(query.toLowerCase())
    );
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ results })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: error.message })
    };
  }
};
